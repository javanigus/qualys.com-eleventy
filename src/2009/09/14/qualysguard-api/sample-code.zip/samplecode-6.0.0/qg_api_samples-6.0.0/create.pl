#!/usr/bin/perl -w
#@(#)$Revision: 1.16 $

# A Perl script, which demonstrates the capabilities of the QualysGuard
# API.

# With this script you can create a QualysGuard prospect account.

# Indentation style: 1 tab = 4 spaces

use HTTP::Request;
use LWP::UserAgent;
require XML::Twig;

my $myname = "create";

my $request;	# HTTP request handle
my $result;		# HTTP response handle
my $server;		# QualysGuard server's FQDN hostname
my $url;		# API access URL
my $xml;		# Twig object handle

# $server may be read from the shell environment, or defaults to
# qualysapi.qualys.com otherwise.

if ($ENV{QWSERV}) {
	$server = $ENV{QWSERV};
} else {
	$server = "qualysapi.qualys.com";
}

# Handlers and helper functions

sub error {
	my ($xml, $element) = @_;

	my $number = $element->att('number');
	my $message;

	# Some APIs return embedded "<SUMMARY>error summary text</SUMMARY>"
	# elements, so detect and handle accordingly. NOTE: <SUMMARY>
	# elements are usually included for reporting multiple errors with
	# one error element.

	if (!($message = $element->first_child_trimmed_text('SUMMARY'))) {
		$message = $element->trimmed_text;
	}

	if ($number) {
		printf STDERR "Request Status: FAILED\nError Number: %1d\nReason: %s\n", $number, $message;
	} else {
		printf STDERR "Request Status: FAILED\nReason: %s\n", $message;
	}

	exit 255;
}

sub generic_return {
	my ($xml, $element) = @_;

	my ($return, $status, $number, $message);

	# This is a GENERIC_RETURN element. So, display the RETURN element,
	# which gives the detailed status.

	if ($return = $element->first_child('RETURN')) {
		$status  = $return->att('status');
		$number  = $return->att('number');
		$message = $return->trimmed_text;

		if ($number) {
			printf STDERR "Request Status: %s\nError Number: %1d\nReason: %s\n", $status, $number, $message;
		} else {
			printf STDERR "Request Status: %s\nReason: %s\n", $status, $message;
		}
	} else {
		# An XML recognition error; display the XML for the offending
		# element.

		printf STDERR "Unrecognized XML Element:\n%s\n", $element->print;
	}

	exit ($status eq "SUCCESS" ? 0 : 255);
}

sub usage {
	printf STDERR "usage: %s admin-username admin-password firstname lastname email company country service account_type billing_type domain targetip partner_id purchased_ips enddate[\"if account_type is customer or internal\"] passworddelivery [\"initialduration\"]\n\n\"initialduration must be specified only if account type is prospect\" \n\n\"enddate must be specified only if account type is internal or cuestomer\" \n\n\"passworddelivery\" refers to the way the user wants the password delivered and can have fax or email as values. If fax, will return the user's password; otherwise the user is sent an activation link by email.\n\nNote: Each positional argument value must comply with the QualysGuard API specifications.\n", $myname;
	exit 1;
}

# XML::Twig uses a parent-child metaphor to traverse the XML document,
# sort of like a directory hierarchy. So, to get the username and
# password values, we have to fetch the content of the <USERNAME>
# and <PASSWORD> elements; if QualysGuard returned any error, then
# the content of the <ERROR> element.

sub subinfo {
	my ($xml, $subinfo) = @_;

	print  "User Created\n";
	printf "Username: %s\n", $subinfo->first_child('USERNAME')->trimmed_text;

	#if ((pop @ARGV) eq "fax") {
	if ($ARGV[14] eq "fax" || $ARGV[15] eq "fax" ){
		printf "Password: %s\n", $subinfo->first_child('PASSWORD')->trimmed_text;
	} else {
		printf "\n%s will receive an email containing account activation instructions.\n", $subinfo->first_child('USERNAME')->trimmed_text;
	}

	exit;
}

# The Perl LWP package gives sufficient capabilities to connect to
# the QualysGuard API. To support the HTTP "Basic Authentication"
# scheme, it's necessary to subclass LWP::UserAgent and define a
# method called "get_basic_credentials", which will be called when
# the server challenges the script for authentication. This method
# returns the username and password, which simply are the second and
# third command line parameters.

# A subclass of LWP::UserAgent to handle HTTP Basic Authentication.

{
	package authUserAgent;
	@ISA = qw(LWP::UserAgent);

	sub new {
		my $self = LWP::UserAgent::new(@_);
		$self;
	}

	sub get_basic_credentials {
		return ($ARGV[0], $ARGV[1]);
	}
}

# XML::Twig is a handy way to process an XML document. Here, we attach
# a userinfo() handler, which is triggered whenever a <USERINFO> tag
# is found in the XML document. We also attach an error() handler,
# which is triggered whenever Twig finds any errors.

$xml = new XML::Twig(
	TwigHandlers => {
		ERROR          => \&error,
		GENERIC_RETURN => \&generic_return,
		SUBSCRIPTIONINFO       => \&subinfo,
	},
	#comments => 'process'
);

usage if ($#ARGV < 15);

my $firstname = $ARGV[2];	# Save first and lastname for later
my $lastname  = $ARGV[3];

if ($ARGV[9] eq "PPH")
{
if ($ARGV[14] eq "fax" || $ARGV[15] eq "fax" ) {
	if ($ARGV[8] eq "prospect") {
		$url = "https://$server/msp/enrollment.php?firstname=$firstname&lastname=$lastname&email=$ARGV[4]&company=$ARGV[5]&country=$ARGV[6]&service=$ARGV[7]&account_type=$ARGV[8]&billing_type=$ARGV[9]&domain=$ARGV[10]&targetip=$ARGV[11]&partner_id=$ARGV[12]&purchased_ips=$ARGV[13]&password_delivery=fax&initial_duration=$ARGV[15]";
		}else {
		$url = "https://$server/msp/enrollment.php?firstname=$firstname&lastname=$lastname&email=$ARGV[4]&company=$ARGV[5]&country=$ARGV[6]&service=$ARGV[7]&account_type=$ARGV[8]&billing_type=$ARGV[9]&domain=$ARGV[10]&targetip=$ARGV[11]&partner_id=$ARGV[12]&purchased_ips=$ARGV[13]&enddate=$ARGV[14]&password_delivery=fax";
}

} else {
	if ($ARGV[8] eq "prospect") {
		$url = "https://$server/msp/enrollment.php?firstname=$firstname&lastname=$lastname&email=$ARGV[4]&company=$ARGV[5]&country=$ARGV[6]&service=$ARGV[7]&account_type=$ARGV[8]&billing_type=$ARGV[9]&domain=$ARGV[10]&targetip=$ARGV[11]&partner_id=$ARGV[12]&purchased_ips=$ARGV[13]&password_delivery=email&initial_duration=$ARGV[15]";
		}else {
		$url = "https://$server/msp/enrollment.php?firstname=$firstname&lastname=$lastname&email=$ARGV[4]&company=$ARGV[5]&country=$ARGV[6]&service=$ARGV[7]&account_type=$ARGV[8]&billing_type=$ARGV[9]&domain=$ARGV[10]&targetip=$ARGV[11]&partner_id=$ARGV[12]&purchased_ips=$ARGV[13]&enddate=$ARGV[14]&password_delivery=email";
}
}
}else{
if ($ARGV[14] eq "fax" || $ARGV[15] eq "fax") {
	if ($ARGV[8] eq "prospect") {
		$url = "https://$server/msp/enrollment.php?firstname=$firstname&lastname=$lastname&email=$ARGV[4]&company=$ARGV[5]&country=$ARGV[6]&service=$ARGV[7]&account_type=$ARGV[8]&billing_type=$ARGV[9]&domain=$ARGV[10]&targetip=$ARGV[11]&partner_id=$ARGV[12]&purchased_scans=$ARGV[13]&password_delivery=fax&initial_duration=$ARGV[15]";
		}else {
		$url = "https://$server/msp/enrollment.php?firstname=$firstname&lastname=$lastname&email=$ARGV[4]&company=$ARGV[5]&country=$ARGV[6]&service=$ARGV[7]&account_type=$ARGV[8]&billing_type=$ARGV[9]&domain=$ARGV[10]&targetip=$ARGV[11]&partner_id=$ARGV[12]&purchased_scans=$ARGV[13]&enddate=$ARGV[14]&password_delivery=fax";
}

} else {
	if ($ARGV[8] eq "prospect") {
		$url = "https://$server/msp/enrollment.php?firstname=$firstname&lastname=$lastname&email=$ARGV[4]&company=$ARGV[5]&country=$ARGV[6]&service=$ARGV[7]&account_type=$ARGV[8]&billing_type=$ARGV[9]&domain=$ARGV[10]&targetip=$ARGV[11]&partner_id=$ARGV[12]&purchased_scans=$ARGV[13]&password_delivery=email&initial_duration=$ARGV[15]";
		}else {
		$url = "https://$server/msp/enrollment.php?firstname=$firstname&lastname=$lastname&email=$ARGV[4]&company=$ARGV[5]&country=$ARGV[6]&service=$ARGV[7]&account_type=$ARGV[8]&billing_type=$ARGV[9]&domain=$ARGV[10]&targetip=$ARGV[11]&partner_id=$ARGV[12]&purchased_scans=$ARGV[13]&enddate=$ARGV[14]&password_delivery=email";
}
}
}

# Setup the request

$request = new HTTP::Request GET => $url;

# Create an instance of the authentication user agent

my $ua = authUserAgent->new;

# Make the request

$result = $ua->request($request);

# Check the result

if ($result->is_success) {
	# Parse the XML

	$xml->parse($result->content);
} else {
	# An HTTP related error

	printf STDERR "HTTP Error: %s\n", $result->status_line;
	exit 1;
}
