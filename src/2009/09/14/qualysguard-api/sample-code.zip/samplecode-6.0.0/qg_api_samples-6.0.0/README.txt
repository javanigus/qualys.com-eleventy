QualysGuard(R) MSP API Sample Code README
@(#)$Revision: 1.13 $

Copyright 2007 by Qualys, Inc. All Rights Reserved.
http://www.qualys.com

DIRECTORY CONTENTS
------------------

This directory contains sample code that demonstrates the functionality
of the QualysGuard MSP API. Several sample scripts are provided to
show how to use MSP API features to perform network security audits
and vulnerability management.

DEPENDENCIES FOR PERL SAMPLES
-----------------------------

Perl versions 5.6.0 and greater are supported. 

The Perl scripts rely on several freely available modules from CPAN.
You will need to have the following installed:

   Bundle::LWP -- Basic WWW library

   Net::SSL    -- SSL support
      Requires OpenSSL

   XML::Twig   -- Handy XML manipulation
      Requires James Clark's expat and XML::Expat
      
These modules must be installed for the samples addassetip.pl:

   Config::Simple;
   HTTP::Request;
   LWP::UserAgent;
     
This module must be installed for the sample usercreate.pl:

   URI::Escape;


SAMPLE SCRIPTS
--------------

The following sample scripts are included and described in more detail
below:

about.pl
acceptEULA.pl
addassetip.pl
compare.pl
create.pl
getmap.pl
getscan.pl
scanoptions.pl
scheduledscans.pl
score.pl
usercreate.pl
vulnsummary.pl

Note: All scripts take a username and password as the first two
command line arguments.

- about.pl

This script returns the version ID strings for the QualysGuard MSP API,
the web application, scanner software, and vulnerability signatures.

If the optional parameter "time" is given, then the script will report
the list of all available time zone codes.

- acceptEULA.pl

This script demonstrates how to accept the Qualys Service End User
License Agreement (EULA) on behalf of a customer.

- addassetip.pl

This script adds asset IP addresses to a QualysGuard subscription by 
importing the assets from a CSV file. This script may be run using an
account that is defined with the Manager user role.

Using this script, you can bulk populate IP addresses and related
host information in QualysGuard using asset data already available in
spreadsheets or data exported from a database. The script demonstrates
this capability by taking properly formatted CSV data with user-supplied
asset attributes as input, and transforming this input into a URL that
will populate the QualysGuard account with asset information. The CSV
file and user-supplied attributes are provided in the addassetip.conf
file, which is provided with this script. The CSV file must have a 
single column with each row containing a single IP address or an IP range.

Please note that the amount of asset data that can be imported into
QualysGuard using this script is limited by the number of characters
allowed in a single URL. For this reason it is recommended that you 
specify IP ranges to overcome this limitation.

- compare.pl

This script totals the severity levels for vulnerabilities detected
by a QualysGuard scan and calculates a total score. This score can be
calculated from an existing scan, or from running a scan. This base
score is compared to the most recent score for the same IP address
range, if one exists, and the difference is reported.

- create.pl

This script demonstrates how to create a new QualysGuard user account
for a subscriber. The script differs from the others in that it
requires QualysGuard administrator credentials (username and password)
to be passed on the command line.

It also shows how to specify all required attributes for a new user
and it displays the results of the operation as success or failure.

Upon success, the new user account may be viewed in the QualysGuard
Admin application (the Back Office).

To activate the account, the administrator may inform the new user
of his username and password, or the new user must click on a link
sent by email. The mode is selected by the presence or absence of
the return password "yes" value on the command line.

- getmap.pl

This script demonstrates how to interact with the QualysGuard network
map functions including: Launch a map, launch a map and save the
report on the QualysGuard server, list saved map reports, retrieve
a saved map report, list maps in progress, and cancel a running map.

It also demonstrates how to connect to the QualysGuard API (using
basic authentication over SSL), how to pass arguments, and how to
display the results of interacting with it.

If called with a netblock-delimited domain, or a list of domains, then
the map-2.php API call is used (otherwise the map.php call will be used
by default).

- getscan.pl

This script demonstrates how to interact with the QualysGuard scan
functions including: Launch a scan, launch a scan and save the report
on the QualysGuard server, list saved scan reports, retrieve a saved
scan report, list scans in progress, and cancel a running scan.

It also demonstrates how to connect to the QualysGuard API (using
basic authentication over SSL), how to provide arguments, and how to
display the results of interacting with it.

- scanoptions.pl

This script demonstrates how to interact with scan service options. The
following options may be set: Scan dead hosts, ports to scan, and scan
hosts behind a load balancer.

- scheduledscans.pl

This script demonstrates how to define scan or map tasks to occur on
a regular basis -- daily, weekly, or monthly.

When executed, it displays the results of interacting with the
QualysGuard task scheduling features including: Set scheduled tasks,
list scheduled tasks, and delete scheduled tasks.

The script also shows how to extract the current list of scheduled
tasks from the returned XML document upon success. For each scheduled
task the following information is displayed: Task status, reference
code, title, target IP address or range, and the date and time when
the task will next be launched.

- score.pl

This script, like vulnsummary.pl, demonstrates how to connect to the
QualysGuard API, and how to extract and display data from the scan
report XML document.

It displays an overall vulnerability score, calculated by adding the
severity levels of the individual vulnerabilities detected during
a scan.

- usercreate.pl

This script adds user accounts to an existing subscription by 
importing user account information from a user-defined CSV file. 
This script may be run using an account that is defined for a Manager 
or Unit Manager.

When the script is run, new users are added based on user-defined 
parameters provided in the usercreate.conf file and a CSV file. 
The script parses every row of the given comma separated file, 
which defines account parameters for users to be added. The columns 
correspond to input parameters for the user.php API function, 
which is documented in the QualysGuard API User Guide. Rows for 
required user.php API parameters must be specified. A sample CSV 
file is provided, with columns for the various parameters 
required to invoke the user.php API call.

- vulnsummary.pl

This script demonstrates how to connect to the QualysGuard API and
how to extract vulnerability data from the scan report XML document.

It returns a list of vulnerabilities, the IP address(es) affected,
their severity, and a short description of each.

The scan report XML document, which contains the vulnerability data
for a particular scan, is obtained by executing a scan when the script
runs or by retrieving a previously saved scan report.
